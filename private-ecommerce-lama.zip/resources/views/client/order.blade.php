@php
$id = Auth::id();
$showNavigation = false;
$bodyType = 'site-menubar-unfold site-menubar-show site-navbar-collapse-show';
@endphp

@extends('app')

@section('page')
    <div class="row">
        <div class="col-lg-12">
            <!-- Panel -->
            <div class="panel">
                <div class="panel-body nav-tabs-animate nav-tabs-horizontal" data-plugin="tabs">
                    <ul class="nav nav-tabs nav-tabs-line" role="tablist">
                        @if (Auth::user()->group_id === 'DRIVER')                             
                        <li class="nav-item" role="presentation"><a class="active nav-link" data-toggle="tab" href="#proses" aria-controls="proses" role="tab">Pesanan Barang</a></li>
                        @elseif (Auth::user()->group_id === 'AGENT' || Auth::user()->group_id === 'CUSTOMER')
                        <li class="nav-item" role="presentation"><a class="active nav-link" data-toggle="tab" href="#proses" aria-controls="proses" role="tab">Pesanan Proses</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#tertunda" aria-controls="tertunda" role="tab">Pesanan Tertunda</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#return" aria-controls="return" role="tab">Return Pesanan</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#pesanan" aria-controls="pesanan" role="tab">Riwayat Pesanan</a></li>
                        @endif
                    </ul>

                    <div class="tab-content">
                        @if (Auth::user()->group_id === 'DRIVER')                        
                        <div class="tab-pane active animation-slide-left" id="proses" role="tabpanel">
                            <div class="example-wrap">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped" id="table-pickup">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Toko</th>
                                                <th>Alamat</th>
                                                <th>Tanggal Pesan</th>
                                                <th>Tanggal Kirim</th>
                                                <th>Status</th>
                                                <th class="text-center">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        @elseif (Auth::user()->group_id === 'AGENT' || Auth::user()->group_id === 'CUSTOMER')
                        <div class="tab-pane active animation-slide-left" id="proses" role="tabpanel">
                            <div class="example-wrap">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped" id="table-prosses">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>No. Nota</th>
                                                <th>Tanggal Pesan</th>
                                                <th>Total Pesanan</th>
                                                <th>Status</th>
                                                <th class="text-center">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>     

                        <div class="tab-pane animation-slide-left" id="tertunda" role="tabpanel">
                            <div class="example-wrap">
                                <br>
                                <h4 class="example-title">Daftar Pesanan Tertunda</h4>
                                <div class="example">
                                    <div class="table-responsive">
                                        <table class="table w-full responsive display nowrap" id="tabel_pending" style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Nama</th>
                                                    <th>No. Nota</th>
                                                    <th>Tanggal Pesan</th>
                                                    <th>Total Pesanan</th>
                                                    <th>Qty</th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane animation-slide-left" id="return" role="tabpanel">
                            <div class="example-wrap">
                                <br>
                                <h4 class="example-title">Daftar Return Pesanan</h4>
                                <div class="example">
                                    <div class="table-responsive">
                                        <table class="table w-full responsive display nowrap" id="tabel_return" style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Tgl Return</th>
                                                    <th>Nama</th>
                                                    <th>No. Nota</th>
                                                    <th>Qty</th>
                                                    <th>Alasan</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane animation-slide-left" id="pesanan" role="tabpanel">
                            <div class="example-wrap">
                                <br>
                                <h4 class="example-title">Daftar Riwayat Pesanan</h4>
                                <div class="example">
                                    <div class="table-responsive">
                                        <table class="table display w-full display nowrap" id="tabel_riwayat">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>No. Nota</th>
                                                    <th>Tanggal Pesan</th>
                                                    <th></th>
                                                    <th></th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            @php $no = 1; @endphp
                                            @foreach($riwayat as $i => $arr)
                                            <tbody class="table-section" data-plugin="tableSection">
                                                <tr>
                                                    <td>{{$no++}}</td>
                                                    <td>{{$arr->no_nota}}</td>
                                                    <td colspan="4"><span class='text-muted'><i class='icon md-time'></i> {{$arr->created_at}}</span></td>
                                                </tr>
                                            </tbody>
                                            <tbody>
                                                <tr>
                                                    <th></th>
                                                    <th>Nama Produk</th>
                                                    <th>Status</th>
                                                    <th>Qty</th>
                                                    <th>Harga</th>
                                                    <th>Total Harga</th>
                                                </tr>
                                                @foreach($arr->orders as $j => $p)
                                                <tr>
                                                    <td></td>
                                                    <td>{{$p->product->nama}}</td>
                                                    <td><span class="badge badge-secondary">{{$p->status}}</span></td>
                                                    <td>{{$p->qty}}</td>
                                                    <td>Rp. {{$p->product->harga}}</td>
                                                    <td>Rp. {{$p->qty * $p->product->harga}}</td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                            @endforeach
                                        </table>

                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
                <!-- End Panel -->
            </div>
        </div>
    </div>
@endsection

@section('modal')
    <div class="modal fade example-modal-lg modal-3d-sign" id="modalReturn" aria-hidden="true" aria-labelledby="modalReturn" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-simple modal-center modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Return Pesanan</h4>
                </div>
                <div class="modal-body">
                    <div class="example-wrap">
                        <br>
                        <h4 class="example-title text-center">Daftar produk yang akan di return</h4>
                        <div class="example">
                            <div class="table-responsive">
                                <form id="form-list-return">
                                    @csrf
                                    <input type="hidden" name="id">

                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Nama Produk</th>
                                                <th>Qty</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody-return">
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group form-material col-xl-12">
                    <button type="button" class="btn btn-default" id="resetBtn">Reset
                    </button>
                    <button type="submit" class="btn btn-primary btn-return" id="validateButton1">Return
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade example-modal-lg modal-3d-sign" id="modalPickup" aria-hidden="true" aria-labelledby="modalPickup" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-simple modal-center modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Detail Pengiriman Barang</h4>
                </div>
                <div class="modal-body">
                    <div class="example-wrap">
                        <br>
                        <h4 class="example-title text-center">Daftar barang yang akan dikirim</h4>
                        <div class="example">
                            <div class="table-responsive">
                                <form id="form-list-pickup">
                                    @csrf
                                    <input type="hidden" name="id">

                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Nama Produk</th>
                                                <th>Qty</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody-pickup">
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Back</button>
                    <button type="submit" class="btn btn-primary btn-pickup" id="validateButton1">Pickup</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade example-modal-lg modal-3d-sign" id="modalArrive" aria-hidden="true" aria-labelledby="modalArrive" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-simple modal-center modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Detail Pengiriman Barang</h4>
                </div>
                <div class="modal-body">
                    <div class="example-wrap">
                        <br>
                        <h4 class="example-title text-center">Daftar barang yang sampai</h4>
                        <div class="example">
                            <div class="table-responsive">
                                <form id="form-list-pickup">
                                    @csrf
                                    <input type="hidden" name="id">

                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Nama Produk</th>
                                                <th>Qty</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody-pickup">
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Back</button>
                    <button type="submit" class="btn btn-primary btn-arrive" id="validateButton1">Selesai Pengiriman</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade example-modal-lg modal-3d-sign" id="modalConfirm" aria-hidden="true" aria-labelledby="modalConfirm" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-simple modal-center modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Detail Pengiriman Barang</h4>
                </div>
                <div class="modal-body">
                    <div class="example-wrap">
                        <br>
                        <h4 class="example-title text-center">Daftar barang yang sampai</h4>
                        <div class="example">
                            <div class="table-responsive">
                                <form id="form-list-pickup">
                                    @csrf
                                    <input type="hidden" name="id">

                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Nama Produk</th>
                                                <th>Qty</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody-pickup">
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Back</button>
                    <button type="submit" class="btn btn-primary btn-confirm" id="validateButton1">Konfirmasi</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        var table2;
        var user = `{{Auth::user()->group_id}}`;
        var table;

        $(document).ready(function() {
            // console.log(user);
            if(user === 'AGENT' || user === 'CUSTOMER'){
                table = $('#table-prosses').DataTable({
                    processing: true,
                    serverSide: true,
                    bInfo: false,
                    ajax: `{{ url("data/order/$id/prosses") }}`,
                    columns: [
                        {
                            data: null,
                            render: (data, type, row, meta) => {
                                return meta.row+1
                            }
                        },
                        {
                            data: 'no_nota'
                        },
                        {
                            data: 'created_at',
                            render: (data, type, row, meta) => moment(data).format('dddd, DD MMMM YYYY')
                        },
                        {
                            data: null,
                            render: (data, type, row, meta) => {
                                var total = 0
                                row.orders.forEach(element => {
                                    total += element.qty * element.product.harga
                                });

                                var formatter = new Intl.NumberFormat('en-US', {
                                    style: 'currency',
                                    currency: 'IDR',
                                });

                                return formatter.format(total)
                            }
                        },
                        {
                            data: 'orders.0.status',
                        },
                        {
                            data: 'id',
                            render: (data, type, row, meta) => {
                                if (row.orders.length > 0) {
                                    const total_trc = row.orders[0].tracking.length - 1
                                    const status_trc = row.orders[0].tracking[total_trc].status
                                    // console.log(total_trc);
                                    // console.log(status);
                                    if(`{{Auth::user()->group_id}}` != 'DRIVER'){
                                        if (status_trc == 'WAITING TO PICKUP') {
                                            return `-`
                                        } else if(status_trc == 'SENDING'){
                                            return `-`   
                                        } else if(row.orders[0].status == 'DONE'){
                                            return `-`   
                                        } else if(status_trc == 'ARRIVED'){
                                            return `<button data-id="${ meta.row }" class="btn btn-sm btn-icon btn-pure btn-default on-default go_pickup" data-target="#modalConfirm" data-toggle="modal"  type="button" data-original-title="Return">
                                                        <a href="#" data-toggle="tooltip" data-original-title="Return"><i class="icon md-border-color" aria-hidden="true"></i></a>
                                                    </button>`   
                                        }
                                    }
                                } else {
                                    return '-'
                                }
                            }
                        }
                    ]
                });
            }else if(user === 'DRIVER'){
                table = $('#table-pickup').DataTable({
                    processing: true,
                    serverSide: true,
                    bInfo: false,
                    ajax: `{{ url("data/order/$id/prosses") }}`,
                    columns: [
                        {
                            data: null,
                            render: (data, type, row, meta) => {
                                return meta.row+1
                            }
                        },
                        {
                            data: 'user.name'               
                        },
                        {
                            data: 'user.address'               
                        },
                        {
                            data: 'created_at',
                            render: (data, type, row, meta) => moment(data).format('dddd, DD MMMM YYYY')
                        },
                        {
                            data: 'tgl_dikirim',
                            render: (data, type, row, meta) => moment(data).format('dddd, DD MMMM YYYY')
                        },
                        {
                            data: 'orders.0.status',
                        },
                        {
                            data: 'id',
                            render: (data, type, row, meta) => {
                                const total_trc = row.orders[0].tracking.length - 1
                                const status = row.orders[0].tracking[total_trc].status
                                console.log(total_trc);
                                if(`{{Auth::user()->group_id}}` == 'DRIVER'){
                                    if (status == 'WAITING TO PICKUP') {
                                        return `<button data-id="${ meta.row }" class="btn btn-sm btn-icon btn-pure btn-default on-default go_pickup" data-target="#modalPickup" data-toggle="modal" type="button" data-original-title="Return">
                                                    <a href="#" data-toggle="tooltip" data-original-title="Return"><i class="icon md-truck" aria-hidden="true"></i></a>
                                                </button>`
                                    } else if(status == 'SENDING'){
                                        return `<button data-id="${ meta.row }" class="btn btn-sm btn-icon btn-pure btn-default on-default go_pickup" data-target="#modalArrive" data-toggle="modal" type="button" data-original-title="Return">
                                                    <a href="#" data-toggle="tooltip" data-original-title="Return"><i class="icon md-pin-drop" aria-hidden="true"></i></a>
                                                </button>`   
                                    } else if(status == 'ARRIVED'){
                                        return `-`   
                                    }
                                }
                            }
                        }
                    ]
                });
            }else{}

            $('#table-prosses').on('click', 'td .return-pesanan', function() {
                $el = $('.tbody-return')
                $el.empty()

                const id = $(this).data('id')
                const data = table.rows().data()[id]
                // console.log(id);
                // console.log(data);

                var disableReturn = false
                var whiteList = ['NEW', 'APPROVE']

                $('input[name=id]').val(data.id)

                data.orders.forEach(element => {
                    if (whiteList.includes(element.status)) disableReturn = true
                    const view = `
                    <tr>
                        <td>
                            <div class="checkbox-custom checkbox-warning">
                                <input type="checkbox" id="inputUnchecked" name="returnIds[]" value="${ element.id }">
                                <label for="inputUnchecked"></label>
                            </div>
                        </td>
                        <td class="font-weight-medium">
                            ${ element.product.nama }
                        </td>
                        <td width="15%">
                            <input type="text" class="form-control qty" data-min="1" data-max="1000000000" data-stepinterval="50" data-maxboostedstep="10000000" value="${ element.qty }" name="${ element.id }" />
                        </td>
                    </tr>
                    `

                    $el.append(view)
                })

                if (disableReturn) {
                    $('.btn-return').attr('disabled', true)
                } else {
                    $('.btn-return').attr('disabled', false)
                }
            })

            $('#table-pickup').on('click', 'td .go_pickup', function() {
                $el = $('.tbody-pickup')
                $el.empty()

                const id = $(this).data('id')
                const data = table.rows().data()[id]
                // console.log(id);
                // console.log(data);

                $('input[name=id]').val(data.id)

                data.orders.forEach((element,index) => {
                        //    <div class="checkbox-custom checkbox-warning">
                        //         <input type="checkbox" id="inputUnchecked" name="id_order[]" value="${ element.id }">
                        //         <label for="inputChecked"></label>
                        //     </div>                    
                    const view = `
                    <tr>
                        <td>
                            ${++index}
                            <input hidden type="text" name="id_order[]" value="${ element.id }">
                        </td>
                        <td class="font-weight-medium">
                            ${ element.product.nama }
                        </td>
                        <td width="15%">
                            <input type="text" disabled class="form-control qty" data-min="1" data-max="1000000000" data-stepinterval="50" data-maxboostedstep="10000000" value="${ element.qty }" name="${ element.id }" />
                            <input type="text" hidden class="form-control-plaint qty" data-min="1" data-max="1000000000" data-stepinterval="50" data-maxboostedstep="10000000" value="${ element.qty }" name="${ element.id }" />
                        </td>
                    </tr>
                    `

                    $el.append(view)
                })

            })

            $('#table-prosses').on('click', 'td .go_pickup', function() {
                $el = $('.tbody-pickup')
                $el.empty()

                const id = $(this).data('id')
                const data = table.rows().data()[id]
                console.log(id);
                console.log(data);

                $('input[name=id]').val(data.id)

                data.orders.forEach((element,index) => {
                        //    <div class="checkbox-custom checkbox-warning">
                        //         <input type="checkbox" id="inputUnchecked" name="id_order[]" value="${ element.id }">
                        //         <label for="inputChecked"></label>
                        //     </div>                    
                    const view = `
                    <tr>
                        <td>
                            ${++index}
                            <input hidden type="text" name="id_order[]" value="${ element.id }">
                        </td>
                        <td class="font-weight-medium">
                            ${ element.product.nama }
                        </td>
                        <td width="15%">
                            <input type="text" disabled class="form-control qty" data-min="1" data-max="1000000000" data-stepinterval="50" data-maxboostedstep="10000000" value="${ element.qty }" name="${ element.id }" />
                            <input type="text" hidden class="form-control-plaint qty" data-min="1" data-max="1000000000" data-stepinterval="50" data-maxboostedstep="10000000" value="${ element.qty }" name="${ element.id }" />
                        </td>
                    </tr>
                    `

                    $el.append(view)
                })

            })

            $('.btn-return').click(function() {
                toastr.options = {
                    positionClass: 'toast-bottom-right',
                }

                const data = $('#form-list-return').serialize()
                $.ajax({
                    url: `{{ url("data/order/return") }}`,
                    type: 'POST',
                    data: data,
                    success: (res) => {
                        toastr.options.onShown = () => window.location.reload(true)
                        toastr["success"]("Berhasil mengubah data")
                    }
                })
            })

            $('.btn-pickup').click(function() {
                toastr.options = {
                    positionClass: 'toast-bottom-right',
                }

                const data = $('#form-list-pickup').serialize()
                $.ajax({
                    url: `{{ route("storePickup") }}`,
                    type: 'POST',
                    data: data,
                    success: (res) => {
                        // console.log(res);
                        toastr.options.onShown = () => window.location.reload(true)
                        toastr["success"]("Berhasil mengubah data")
                    }
                })
            })

            $('.btn-confirm').click(function() {
                
                toastr.options = {
                    positionClass: 'toast-bottom-right',
                }

                const data = $('#form-list-pickup').serialize()
                $.ajax({
                    url: `{{ route("storeConfirm") }}`,
                    type: 'POST',
                    data: data,
                    success: (res) => {
                        // console.log(res);
                        toastr.options.onShown = () => window.location.reload(true)
                        toastr["success"]("Berhasil mengubah data")
                    }
                })
            })

            $('.btn-arrive').click(function() {
                toastr.options = {
                    positionClass: 'toast-bottom-right',
                }

                const data = $('#form-list-pickup').serialize()
                $.ajax({
                    url: `{{ route("storeArrive") }}`,
                    type: 'POST',
                    data: data,
                    success: (res) => {
                        // console.log(res);
                        toastr.options.onShown = () => window.location.reload(true)
                        toastr["success"]("Berhasil mengubah data")
                    }
                })
            })


            var pending_column = ["id", "nama_produk", "no_nota", "tgl_pesan", "total_pesanan", "qty"];
            var return_column = ["id", "tgl_return", "nama_produk", "no_nota", "qty", "alasan", "status"];
            dataTable("#tabel_pending", pending_column, 'pending');
            dataTable("#tabel_return", return_column, 'return');
            $("#tabel_riwayat").DataTable({ dom:'' });
        })

        function dataTable(table, column, url) {
            var $table = table;
            var $url = "{{url('/profile_')}}" + url;

            var $column = []
            for (i in column) {
                var a;
                if (i == 0) {
                    $column.push({
                        "data": column[i],
                        "name": column[i],
                        "orderable": false,
                        "searchable": false,
                        "render": function(data, type, row, meta) {
                            return meta.row + 1;
                        }
                    })
                } else {
                    $column.push({
                        "data": column[i],
                        "name": column[i]
                    })
                }
            }

            table2 = $($table).DataTable({
                processing: true,
                serverSide: false,
                dom: '',
                ajax: {
                    url: $url,
                    type: "GET"
                },
                columns: $column
            });
        }
    </script>
@endsection
