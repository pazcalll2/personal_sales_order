<?php

namespace App\Http\Controllers;

use App\Order;
use App\Tracking;
use App\PurchaseOrder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{

    public function index()
    {
        // $user = Auth::user();
        // if($user->group_id == 'DRIVER'){
        //     $riwayat = PurchaseOrder::with(['orders.product', 'orders' => function($db) {
        //         return $db->whereIn('status', ['NEW', 'APPROVE', 'SENT']);
        //     }])->get();
        // }elseif($user->group_id == 'CUSTOMER'){
        // }elseif($user->group_id == 'AGENT'){
        // }else{}
        $riwayat = PurchaseOrder::where('user_id', Auth::user()->id)->with(['user', 'orders.product'])->get();
        return view('client.order', compact('riwayat'));
    }

    public function viewRiwayat() {
        return view('dashboard.riwayat');
    }

    public function dataRiwayat() {
        $data = PurchaseOrder::orderBy('created_at', 'desc')
            ->with(['orders.product', 'user'])
            ->get();
        return datatables($data)->toJson();
    }

    public function proses($id) {
        $user = Auth::user();
        // if($user->group_id == 'DRIVER'){
        //     $riwayat = PurchaseOrder::with(['orders.product', 'orders' => function($db) {
        //         return $db->whereIn('status', ['NEW', 'APPROVE', 'SENT']);
        //     }])->get();
        // }elseif($user->group_id == 'CUSTOMER'){
        // }elseif($user->group_id == 'AGENT'){
        // }else{}
        $dataSend = [];
        $data = PurchaseOrder::with(['user', 'orders.product', 'orders' => function($db) {
                    return $db->whereIn('status', ['NEW', 'APPROVE', 'SENT','PREPARE','ARRIVED','DONE']);
                },'orders.tracking' => function($db1) use ($user) {
                    if($user->group_id == 'DRIVER'){
                        return $db1->where('driver_id', $user->id);
                    }else{
                        return $db1;
                    }
                }])
            ->when($user, function ($query) use ($user, $id) {
                if($user->group_id == 'DRIVER'){
                    return $query;
                }elseif($user->group_id == 'CUSTOMER' || 'AGENT'){
                    return $query->where('user_id', $id);
                }else{
                    return $query;
                }
            })
            ->get();

        // return $data;

        if(count($data) > 0) {
            foreach ($data as $key => $value) {
                
                if (count($value->orders) > 0) {
                    if(count($value->orders[0]->tracking) <= 0){
                        // return $value->orders[0];
                        continue; 
                    }else{
                        $dataSend[$key] = $value;
        
                        foreach ($value->orders as $key1 => $value1) {
                            foreach ($value1->tracking as $key2 => $value2) {
                                if($value2->status == 'SENDING'){
                                    // return $value2->status;
                                    $dataSend[$key]->tgl_dikirim = (string)$value2->created_at;
                                }else{
                                    $dataSend[$key]->tgl_dikirim = '-';
                                }
                            }
                        }
                    }
                } 
                
            }
        }
            // ->whereHas('orders', function($db) {
            //     return $db->whereIn('status', ['NEW', 'APPROVE', 'SENT']);
            // });
        return datatables($dataSend)->toJson();
    }

    public function tertunda($id) {
        $data = Order::where('status', 'PENDING')->whereHas('po', function($query) use ($id) {
                return $query->where('user_id', $id);
            })
            ->with(['product', 'po']);
        return datatables($data)->toJson();
    }

    public function return($id) {
        $data = Order::where('status', 'RETURN')->whereHas('po', function($query) use ($id) {
            return $query->where('user_id', $id);
        });
        return datatables($data)->toJson();
    }

    public function storeReturn(Request $request) {
        $orderIds = $request->input('returnIds') ?? [];
        $purchaseOrder = PurchaseOrder::find($request->input('id'));
        $purchaseOrder->orders->each(function($item, $key) use ($orderIds, $request) {
            foreach ($orderIds as $i => $it) {
                if ($item->id == $it) {
                    $replicate = $item->replicate();
                    $replicate->qty = $request->input($it);
                    $replicate->status = 'RETURN';
                    $replicate->save();

                    $item->status = 'DONE';
                    $item->save();

                    return;
                }
            }

            if ($item->status != 'PENDING' || $item->status != 'RETURN') {
                $item->status = 'DONE';
                $item->save();
            }
        });

        return response(['data' => 'success'], 200);
    }

    public function storePickup(Request $request) {
        // return $request->all();
        $orderIds = $request->input('id_order') ?? [];
        $purchaseOrder = PurchaseOrder::find($request->input('id'));

        $order = Order::whereIn('id',$orderIds)->each(function($item, $key) use ($orderIds, $request) {
            $item->qty = $request->input($item->id);
            $item->status = 'SENT';
            $item->save();
            
            Tracking::create([
                'order_id' => $item->id,
                'driver_id' => Auth::user()->id,
                'target' => $item->po->user->group_id,
                'status' => 'SENDING'
            ]);     
        });

        return response(['data' => 'success'], 200);
    }

    public function storeArrive(Request $request) {
        // return $request->all();
        $orderIds = $request->input('id_order') ?? [];
        $purchaseOrder = PurchaseOrder::find($request->input('id'));

        $order = Order::whereIn('id',$orderIds)->each(function($item, $key) use ($orderIds, $request) {
            $item->qty = $request->input($item->id);
            $item->status = 'ARRIVED';
            $item->save();
            
            Tracking::create([
                'order_id' => $item->id,
                'driver_id' => Auth::user()->id,
                'target' => $item->po->user->group_id,
                'status' => 'ARRIVED'
            ]);     
        });

        return response(['data' => 'success'], 200);
    }

    public function storeConfirm(Request $request) {
        // return $request->all();
        $orderIds = $request->input('id_order') ?? [];
        $purchaseOrder = PurchaseOrder::find($request->input('id'));

        $order = Order::whereIn('id',$orderIds)->each(function($item, $key) use ($orderIds, $request) {
            $item->qty = $request->input($item->id);
            $item->status = 'DONE';
            $item->save();
            
        });

        return response(['data' => 'success'], 200);
    }

    public function riwayat($id) {
        $data = PurchaseOrder::where('user_id', $id)->whereHas('orders', function($db) {
            return $db->where('status', 'DONE');
        });
        return datatables($data)->toJson();
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Order $order)
    {
        //
    }

    public function edit(Order $order)
    {
        //
    }

    public function update(Request $request, $order)
    {
        // return $request->all();
        $data = Order::find($order);
        $params = $request->post('data');
        foreach($params as $key => $item) {
            // return $key; 
            if ($key === 'qty') {
                $newQty = $data->qty - $params[$key];

                $replicate = $data->replicate();
                $replicate->status = 'PENDING';
                $replicate->qty = $newQty;
                $replicate->created_at = date('Y-m-d H:i:s');
                $replicate->save();

                // $replicate1 = $data->replicate();

                $data->status = 'APPROVE';
                $data->qty = $params[$key];
            } else {
                $data->$key = $item;
            }
        }

        $data->save();

        return response(['data' => $request->post('data')], 200);
    }
}
