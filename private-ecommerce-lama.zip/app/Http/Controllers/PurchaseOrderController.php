<?php

namespace App\Http\Controllers;

use App\LogStock;
use App\Order;
use App\Product;
use App\PurchaseOrder;
use App\Tracking;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PurchaseOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard.purchase-order');
    }

    public function perintahKirim()
    {
        return view('dashboard.perintah-kirim');
    }

    public function tagihan()
    {
        return view('dashboard.tagihan');
    }

    public function dataTagihan(){
        return response([
            'status'  => 'message',
            'message' => 'Berhasil load data',
            'data'    => PurchaseOrder::whereHas('orders', function($table)  {
                return $table->where('jatuh_tempo','!=',null);
            })
            ->with('orders.product.stock', 'user')
            ->get()
        ], 200);
    }

    public function detailTagihan(Request $request){
        return response([
            'status'  => 'message',
            'message' => 'Berhasil load data',
            'data'    => Order::whereHas('po', function($table) use ($request)  {
                return $table   ->where('po_id', $request->po_id)
                                ->whereIn('status', ['SENT','NEW']);
            })->with('po.user','product')
            ->get()
        ], 200);
    }


    public function pending() {
        return view('dashboard.pending-order');
    }

    public function newPurchaseOrder() {
        return $this->loadData('NEW');
    }

    public function pendingOrder() {
        return $this->loadData('PENDING');
    }

    public function sentOrder() {
        return $this->loadData('APPROVE');
    }

    public function riwayat() {
        $data = PurchaseOrder::with(['orders.product.stock', 'user', 'orders'])->orderBy('created_at', 'desc')->get();
        return response([
            'status'  => 'message',
            'message' => 'Berhasil load data',
            'data'    => $data
        ], 200);
    }

    private function loadData($query)
    {
        $data = PurchaseOrder::with(['orders.product.stock', 'user', 'orders' => function($db) use ($query) {
                return $db->where('status', $query);
            }])
            ->whereHas('orders', function($table) use ($query) {
                return $table->where('status', $query);
            })
            ->get();

        return response([
            'status'  => 'message',
            'message' => 'Berhasil load data',
            'data'    => $data
        ], 200);
    }

    public function store(Request $request)
    {
        // dd($request->input('data'), $request->input('total'));
        DB::beginTransaction();
        if (Auth::user()->group_id == 'AGENT') {
            $limit = Auth::user()->agent->limit;
            if ($request->input('total') >= $limit) {
                return response([
                    'status'  => 'error',
                    'message' => 'Anda melebihi limit belanja.',
                    'data'    => []
                ], 400);
            }
        }
        try {

            $noNota = function() {
                return strtoupper(Str::random(20));
            };

            $purchaseOrder = PurchaseOrder::create([
                'no_nota' => $noNota(),
                'user_id' => Auth::user()->id ]
            );

            foreach($request->input('data') as $i => $item) {
                Order::create([
                    'po_id'      => $purchaseOrder->id,
                    'product_id' => $item['id'],
                    'qty'        => $item['qty']
                ]);
            }

            DB::commit();

            return response([
                'message' => 'Terimakasih sudah membeli product kami',
                'data' => []
            ], 200);
        } catch(Exception $e) {
            DB::rollBack();

            return response(['message' => ''], 400);
        }
    }

    public function sentPesanan(Request $request){
        try {
            DB::beginTransaction();
            // return $request->all();
            foreach($request->data as $i => $arr) {
                foreach ($arr as $key => $items) {
                    Order::where('po_id', $items['po_id'])->where('status', 'APPROVE')->get()->each(function($item, $key) use ($request) {
                        // DD($items->po->user->group_id);
                        $item->status = 'PREPARE';
                        $purchaseOrder = PurchaseOrder::where('no_nota', $item->po->no_nota)->first();
                        $purchaseOrder->jatuh_tempo = $request->input('jatuh_tempo');
                        $purchaseOrder->save();

                        Tracking::create([
                            'order_id' => $item->id,
                            'driver_id' => $request->id_driver,
                            'target' => $item->po->user->group_id,
                            'status' => 'WAITING TO PICKUP'
                        ]);

                        $stock = Product::find($item->product_id)->stock;
                        $stock->stock = $stock->stock - $item->qty;

                        LogStock::create([
                            'stock_id' => $stock->id,
                            'type' => 'OUT',
                            'note' => "Barang dibeli oleh ". $item->target. ' dengan nama : '. $item->po->user->name,
                            'before' => $stock->stock,
                            'current' => $stock->stock - $item->qty
                        ]);

                        $stock->save();
                        $item->save();
                    });
                }
            }
            DB::commit();
            $code = 200;
        } catch(Exception $e) {
            DB::rollBack();
            $code = 400;
        }

        return response([
            'message' => 'Berhasil mengubah status order menjadi dikirim',
            'data' => []
        ], $code);
    }
}
