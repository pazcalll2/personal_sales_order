<?php

namespace App\Http\Controllers;

use App\Tagihan;
use Illuminate\Http\Request;

class TagihanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard.kirim-tagihan');
    }
    
    public function bayar()
    {
        return view('dashboard.bayar-tagihan');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tagihan  $tagihan
     * @return \Illuminate\Http\Response
     */
    public function show(Tagihan $tagihan)
    {
        return view('dashboard.lihat-tagihan');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Tagihan  $tagihan
     * @return \Illuminate\Http\Response
     */
    public function edit(Tagihan $tagihan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tagihan  $tagihan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tagihan $tagihan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tagihan  $tagihan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tagihan $tagihan)
    {
        //
    }

    public function cetak_tagihan(Request $request)
    {
        $id_po = $request->id_po;

        $mpdf = new \Mpdf\Mpdf([
            //'tempDir'             =>  __DIR__ . '/tmp',
            'format'              => 'A4-P',
            'mode'                => 'utf-8',
            'setAutoTopMargin'    => 'stretch',
            'defaultheaderline'   => 0,
            'defaultfooterline'   => 0
        ]);

        $mpdf->SetMargins(0, 0, 12);

        $html = view('dashboard.pdf_tagihan');
        // return $html;
        $header = '
        <table width="100%">
        <tr>
        <td width="60%" style="color:#000D00;font-size: 20pt;font-weight: bold; ">TAGIHAN</td>
        <td width="40%" style="text-align: right;">
            <table width="100%">
            <tr>
                <td width="50%" style="color:rgba(58,54,68,1);font-size: 8pt; ">
                No. Nota
                <td width="50%" style="text-align: right;">
                <span style="font-size: 8pt;">0012345</span>
                </td>
            </tr>
            <tr>
                <td width="50%" style="color:rgba(58,54,68,1);font-size: 8pt; ">
                Tanggal
                <td width="50%" style="text-align: right;">
                <span style="font-size: 8pt;">12 Juli 2021</span>
                </td>
            </tr>
            <tr>
                <td width="50%" style="color:rgba(58,54,68,1);font-size: 8pt; ">
                Jatuh Tempo
                <td width="50%" style="text-align: right;">
                <span style="font-size: 8pt;">14 Juli 2021</span>
                </td>
            </tr>
            <tr>
                <td width="50%" style="color:rgba(58,54,68,1);font-size: 8pt; ">
                Dikirim Oleh
                <td width="50%" style="text-align: right;">
                <span style="font-size: 8pt;">Hari Aji</span>
                </td>
            </tr>
            </table>
        </td>
        </tr>
        </table>
        ';


        $mpdf->SetHeader($header);
        $footer = '
        <div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 3mm; ">
        Page {PAGENO} of {nb}
        </div>        
        ';
        $mpdf->setFooter($footer);
        // $mpdf->SetDisplayMode('fullpage');
        // $mpdf->WriteHTML($html);

        // $mpdf->Output('Rekam Medis', 'I');
                
        //     $mpdf = new \Mpdf\Mpdf([
        //         'margin_left' => 20,
        //         'margin_right' => 15,
        //         'margin_top' => 48,
        //         'margin_bottom' => 25,
        //         'margin_header' => 10,
        //         'margin_footer' => 10
        //     ]);

            $mpdf->SetProtection(array('print'));
            $mpdf->SetTitle("Acme Trading Co. - Invoice");
            $mpdf->SetAuthor("Acme Trading Co.");
            $mpdf->SetWatermarkText("Paid");
            $mpdf->showWatermarkText = true;
            $mpdf->watermark_font = 'DejaVuSansCondensed';
            $mpdf->watermarkTextAlpha = 0.1;
            $mpdf->SetDisplayMode('fullpage');

            $mpdf->WriteHTML($html);

            $mpdf->Output();        
    }
}
