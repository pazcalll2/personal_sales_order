<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tracking extends Model
{
    //
    use Columns;

    public function orders() {
        return $this->belongsTo(Order::class, 'order_id');
    }
}
