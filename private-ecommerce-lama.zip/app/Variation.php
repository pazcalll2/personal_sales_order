<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Variation extends Model
{
    use Columns;
    
}
